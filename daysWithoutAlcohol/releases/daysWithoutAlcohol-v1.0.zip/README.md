# <img src="imgs/favicon.ico" alt="Icon" height="25px" > Days Without Alcohol

Pretty straight forward. A GitHub-like calendar in which, every day, you can mark it as another day that you didn't have any alcohol!

**I drank alcohol,** on the other hand, will mark the current day as a non-sober day.

![Days Without Alcohol example](../docs/imgs/daysWithoutAlcohol.png)

You can try it [here](https://garz4.github.io/venting/daysWithoutAlcohol).

## Credits

Logo [designed by Freepik](http://www.freepik.com).
